let card1var = 0;
let card2var = 0;
let card3var = 0;
let card4var = 0;
let card5var = 0;
let card6var = 0;
let card7var = 0;
let card8var = 0;


function Rotatecard1() {
  // document.getElementById("card1").focus();
  if (card1var == 0) {
    document.getElementById("card1").style.transform = "rotateY(180deg)";
    document.getElementById("card1").style.transitionDuration = "1.5s";
    card1var = 1;
  } else if (card1var == 1) {
    document.getElementById("card1").style.transform = "rotateY(0deg)";
    card1var = 0;
  }
}

function Rotatecard2() {
  // document.getElementById("card1").focus();
  if (card2var == 0) {
    document.getElementById("card2").style.transform = "rotateY(180deg)";
    document.getElementById("card2").style.transitionDuration = "1.5s";
    card2var = 1;
  } else if (card2var == 1) {
    document.getElementById("card2").style.transform = "rotateY(0deg)";
    card2var = 0;
  }
}

function Rotatecard3() {
  // document.getElementById("card1").focus();
  if (card3var == 0) {
    document.getElementById("card3").style.transform = "rotateY(180deg)";
    document.getElementById("card3").style.transitionDuration = "1.5s";
    card3var = 1;
  } else if (card3var == 1) {
    document.getElementById("card3").style.transform = "rotateY(0deg)";
    card3var = 0;
  }
}

function Rotatecard4() {
  // document.getElementById("card1").focus();
  if (card4var == 0) {
    document.getElementById("card4").style.transform = "rotateY(180deg)";
    document.getElementById("card4").style.transitionDuration = "1.5s";
    card4var = 1;
  } else if (card4var == 1) {
    document.getElementById("card4").style.transform = "rotateY(0deg)";
    card4var = 0;
  }
}

function Rotatecard5() {
  // document.getElementById("card1").focus();
  if (card5var == 0) {
    document.getElementById("card5").style.transform = "rotateY(180deg)";
    document.getElementById("card5").style.transitionDuration = "1.5s";
    card5var = 1;
  } else if (card5var == 1) {
    document.getElementById("card5").style.transform = "rotateY(0deg)";
    card5var = 0;
  }
}

function Rotatecard6() {
  // document.getElementById("card1").focus();
  if (card6var == 0) {
    document.getElementById("card6").style.transform = "rotateY(180deg)";
    document.getElementById("card6").style.transitionDuration = "1.5s";
    card6var = 1;
  } else if (card6var == 1) {
    document.getElementById("card6").style.transform = "rotateY(0deg)";
    card6var = 0;
  }
}

function Rotatecard7() {
  // document.getElementById("card1").focus();
  if (card7var == 0) {
    document.getElementById("card7").style.transform = "rotateY(180deg)";
    document.getElementById("card7").style.transitionDuration = "1.5s";
    card7var = 1;
  } else if (card7var == 1) {
    document.getElementById("card7").style.transform = "rotateY(0deg)";
    card7var = 0;
  }
}

function Rotatecard8() {
  // document.getElementById("card1").focus();
  if (card8var == 0) {
    document.getElementById("card8").style.transform = "rotateY(180deg)";
    document.getElementById("card8").style.transitionDuration = "1.5s";
    card8var = 1;
  } else if (card8var == 1) {
    document.getElementById("card8").style.transform = "rotateY(0deg)";
    card8var = 0;
  }
}